document.addEventListener('DOMContentLoaded', () => {
    var usuario = document.getElementById('usua');
    var sen = document.getElementById('sen');
    var msgUsuario = document.getElementById('msg_u');
    var msgSenha = document.getElementById('msg_s');

    function login() {
        var valorUsuario = usuario.value.trim().toUpperCase();
        var valorSenha = sen.value;
        msgUsuario.textContent = '';
        msgSenha.textContent = '';

       
        if (valorUsuario === "ADMIN" && valorSenha === "1234") {
            alert("Bem-vindo, administrador!");
            window.location.href = 'perfil/index.html';
            return;
        }

        const storedPassword = localStorage.getItem(valorUsuario);

        if (!valorUsuario || !valorSenha) {
            if (!valorUsuario) msgUsuario.textContent = "Usuário é obrigatório";
            if (!valorSenha) msgSenha.textContent = "Senha é obrigatória";
            return;
        }

        if (!storedPassword) {
            msgSenha.textContent = "Usuário não encontrado. Por favor, crie uma conta.";
            return;
        }

        if (storedPassword === valorSenha) {
            alert("Bem-vindo " + valorUsuario + "!");
            window.location.href = 'pósLogin/index.html';
        } else {
            msgSenha.textContent = "Senha incorreta.";
            
        }
    }

    function redCria() {
        window.location.href = 'Cad.html';
    }

    document.getElementById('Login').addEventListener('click', login);
    document.getElementById('redirectCria').addEventListener('click', redCria);
});
