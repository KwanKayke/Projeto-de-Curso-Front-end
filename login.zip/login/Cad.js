document.addEventListener('DOMContentLoaded', () => {
    var nome = document.getElementById('criaUser');
    var senha = document.getElementById('criaSenha');
    var v_senha = document.getElementById('confereSen');
    const msgUser = document.getElementById('msgNome');
    const msgSen = document.getElementById('msgSenha');

    function criarLog() {
        const vNome = nome.value.trim().toUpperCase();
        const vSenha = senha.value;
        const vvSenha = v_senha.value;
        msgUser.textContent = '';
        msgSen.textContent = '';

        if (!vNome || !vSenha || !vvSenha) {
            if (!vNome) msgUser.textContent = "Usuário é obrigatório";
            if (!vSenha) msgSen.textContent = "Senha é obrigatória";
            if (!vvSenha) msgSen.textContent = "Confirmação de senha é obrigatória";
            return;
        } else if (vSenha !== vvSenha) {
            msgSen.textContent = "As senhas não conferem";
            return;
        } else {
            localStorage.setItem(vNome, vSenha);
            alert("Conta criada com sucesso! Redirecionando para o login...");
            window.location.href = 'index.html'; 
        }
    }

    document.getElementById('criaConta').addEventListener('click', criarLog);
});
